-- EmptyReturn starter schema for Supabase PostgreSQL.
-- Run in Supabase SQL Editor only after reviewing and adapting policies.
-- This schema deliberately does NOT store Aadhaar numbers/images. Use an approved
-- verification provider or a separately secured document workflow if legally required.

create extension if not exists pgcrypto;

create type public.app_role as enum ('shipper', 'carrier', 'admin');
create type public.booking_status as enum ('requested', 'accepted', 'pickup_due', 'in_transit', 'delivered', 'cancelled', 'disputed');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.app_role not null default 'shipper',
  display_name text not null default '',
  business_name text,
  phone text,
  verification_status text not null default 'pending' check (verification_status in ('pending','in_review','verified','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  registration_number text not null,
  vehicle_type text not null,
  max_weight_kg numeric not null check (max_weight_kg > 0),
  max_volume_m3 numeric check (max_volume_m3 is null or max_volume_m3 > 0),
  verification_status text not null default 'pending' check (verification_status in ('pending','in_review','verified','rejected')),
  created_at timestamptz not null default now(),
  unique (registration_number)
);

create table public.capacity_listings (
  id uuid primary key default gen_random_uuid(),
  carrier_id uuid not null references public.profiles(id) on delete cascade,
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  origin_city text not null,
  destination_city text not null,
  origin_lat double precision,
  origin_lng double precision,
  destination_lat double precision,
  destination_lng double precision,
  departure_at timestamptz,
  available_weight_kg numeric not null check (available_weight_kg > 0),
  available_volume_m3 numeric check (available_volume_m3 is null or available_volume_m3 > 0),
  asking_price numeric not null check (asking_price >= 0),
  status text not null default 'available' check (status in ('available','reserved','in_transit','completed','withdrawn')),
  created_at timestamptz not null default now()
);

create table public.shipment_requests (
  id uuid primary key default gen_random_uuid(),
  shipper_id uuid not null references public.profiles(id) on delete cascade,
  origin_city text not null,
  destination_city text not null,
  pickup_lat double precision,
  pickup_lng double precision,
  dropoff_lat double precision,
  dropoff_lng double precision,
  pickup_window_start timestamptz,
  pickup_window_end timestamptz,
  cargo_description text not null,
  weight_kg numeric not null check (weight_kg > 0),
  volume_m3 numeric check (volume_m3 is null or volume_m3 > 0),
  budget numeric check (budget is null or budget >= 0),
  handling_notes text,
  status text not null default 'open' check (status in ('open','matched','booked','cancelled','completed')),
  created_at timestamptz not null default now()
);

create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipment_requests(id),
  capacity_listing_id uuid not null references public.capacity_listings(id),
  shipper_id uuid not null references public.profiles(id),
  carrier_id uuid not null references public.profiles(id),
  agreed_price numeric not null check (agreed_price >= 0),
  status public.booking_status not null default 'requested',
  pickup_at timestamptz,
  delivered_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.trip_locations (
  id bigint generated always as identity primary key,
  booking_id uuid not null references public.bookings(id) on delete cascade,
  carrier_id uuid not null references public.profiles(id) on delete cascade,
  latitude double precision not null check (latitude between -90 and 90),
  longitude double precision not null check (longitude between -180 and 180),
  accuracy_m double precision,
  recorded_at timestamptz not null default now()
);
create index trip_locations_booking_time_idx on public.trip_locations(booking_id, recorded_at desc);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

-- Create a profile row on signup. Role assignment must be validated server-side in production;
-- do not let public users promote themselves to admin.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, role, display_name)
  values (new.id, 'shipper', coalesce(new.raw_user_meta_data->>'display_name',''));
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.vehicles enable row level security;
alter table public.capacity_listings enable row level security;
alter table public.shipment_requests enable row level security;
alter table public.bookings enable row level security;
alter table public.trip_locations enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;

-- Basic starter policies. Test carefully and tighten for production.
create policy "profiles readable to authenticated users" on public.profiles
for select to authenticated using (true);
create policy "users update own profile" on public.profiles
for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "verified vehicle listings readable" on public.vehicles
for select to authenticated using (verification_status = 'verified' or owner_id = auth.uid());
create policy "owners manage their vehicles" on public.vehicles
for insert to authenticated with check (owner_id = auth.uid());
create policy "owners update their vehicles" on public.vehicles
for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "available capacity visible to authenticated users" on public.capacity_listings
for select to authenticated using (status = 'available' or carrier_id = auth.uid());
create policy "carriers create own capacity" on public.capacity_listings
for insert to authenticated with check (carrier_id = auth.uid());
create policy "carriers update own capacity" on public.capacity_listings
for update to authenticated using (carrier_id = auth.uid()) with check (carrier_id = auth.uid());

create policy "shippers see own requests" on public.shipment_requests
for select to authenticated using (shipper_id = auth.uid());
create policy "shippers create own requests" on public.shipment_requests
for insert to authenticated with check (shipper_id = auth.uid());
create policy "shippers update own requests" on public.shipment_requests
for update to authenticated using (shipper_id = auth.uid()) with check (shipper_id = auth.uid());

create policy "booking participants can read bookings" on public.bookings
for select to authenticated using (shipper_id = auth.uid() or carrier_id = auth.uid());
create policy "shippers request bookings" on public.bookings
for insert to authenticated with check (shipper_id = auth.uid());
create policy "participants can update booking" on public.bookings
for update to authenticated using (shipper_id = auth.uid() or carrier_id = auth.uid())
with check (shipper_id = auth.uid() or carrier_id = auth.uid());

create policy "booking participants can read trip locations" on public.trip_locations
for select to authenticated using (
  exists (select 1 from public.bookings b where b.id = booking_id and (b.shipper_id = auth.uid() or b.carrier_id = auth.uid()))
);
create policy "carrier can insert own trip location" on public.trip_locations
for insert to authenticated with check (carrier_id = auth.uid());

create policy "booking participants can read messages" on public.messages
for select to authenticated using (
  exists (select 1 from public.bookings b where b.id = booking_id and (b.shipper_id = auth.uid() or b.carrier_id = auth.uid()))
);
create policy "booking participants can send messages" on public.messages
for insert to authenticated with check (
  sender_id = auth.uid() and
  exists (select 1 from public.bookings b where b.id = booking_id and (b.shipper_id = auth.uid() or b.carrier_id = auth.uid()))
);

create policy "users read own notifications" on public.notifications
for select to authenticated using (user_id = auth.uid());
create policy "users update own notifications" on public.notifications
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- IMPORTANT production hardening still required:
-- 1) Replace broad profile visibility with a minimal public profile view.
-- 2) Add server-side admin-only policies/functions; never trust a client-supplied role.
-- 3) Validate capacity/booking ownership and state transitions server-side.
-- 4) Add rate limits, audit logging, retention rules, private document storage and incident handling.
-- 5) Trip locations should only be accepted during active bookings and should be rate-limited.
