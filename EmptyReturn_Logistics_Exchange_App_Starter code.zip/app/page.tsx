"use client";

import { useEffect, useMemo, useState } from "react";
import {
  ArrowDownRight, ArrowUpRight, Bell, Box, CheckCircle2, ChevronDown, CircleHelp,
  Clock3, Compass, FileCheck2, Filter, Gauge, LocateFixed, LogOut, MapPin,
  Menu, MessageCircle, Package, Plus, Search, ShieldCheck, Truck, Users, Wallet,
  X, Navigation, Activity, Settings, LayoutDashboard, Route, ClipboardCheck,
  CircleDollarSign, Send, Eye, EyeOff, UploadCloud, AlertTriangle
} from "lucide-react";
import { supabase } from "@/lib/supabase";

type Role = "shipper" | "carrier" | "admin";
type Listing = {
  id: string; truck: string; driver: string; from: string; to: string; km: number;
  weight: number; volume: number; price: number; eta: string; status: string;
  rating: number; plate: string; lat: number; lng: number; verified: boolean;
};
const sampleListings: Listing[] = [
  { id:"ER-2048", truck:"Tata 407", driver:"Aman Singh", from:"Agra", to:"Delhi", km:230, weight:900, volume:8.5, price:4200, eta:"Today, 4:30 PM", status:"Available", rating:4.9, plate:"UP80 BT 4821", lat:27.1767, lng:78.0081, verified:true },
  { id:"ER-2051", truck:"Eicher Pro 3015", driver:"Ravi Kumar", from:"Jaipur", to:"Agra", km:240, weight:3200, volume:21, price:6800, eta:"Today, 6:00 PM", status:"Available", rating:4.8, plate:"RJ14 GH 7790", lat:26.9124, lng:75.7873, verified:true },
  { id:"ER-2056", truck:"Ashok Leyland Dost", driver:"Imran Khan", from:"Delhi", to:"Agra", km:230, weight:650, volume:5.2, price:3100, eta:"Tomorrow, 9:00 AM", status:"Pending", rating:4.7, plate:"DL1L AC 2409", lat:28.6139, lng:77.2090, verified:false },
];
const money = (n:number) => "₹" + n.toLocaleString("en-IN");
const roleNames: Record<Role,string> = { shipper:"SME / Shipper", carrier:"Truck Owner", admin:"Platform Admin" };

export default function Home() {
  const [role, setRole] = useState<Role>("shipper");
  const [loggedIn, setLoggedIn] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [active, setActive] = useState("Overview");
  const [listings, setListings] = useState<Listing[]>(sampleListings);
  const [query, setQuery] = useState("");
  const [from, setFrom] = useState("Agra");
  const [to, setTo] = useState("Delhi");
  const [weight, setWeight] = useState("380");
  const [volume, setVolume] = useState("2.4");
  const [budget, setBudget] = useState("5000");
  const [toast, setToast] = useState("");
  const [chatText, setChatText] = useState("");
  const [chatMessages, setChatMessages] = useState([{ sender:"Aman Singh", text:"Hi! I have spare capacity on my return trip to Delhi.", time:"10:42 AM" }]);
  const [booking, setBooking] = useState<Listing|null>(null);
  const [mapReady, setMapReady] = useState(false);
  const [trackingOn, setTrackingOn] = useState(false);
  const [gpsStatus, setGpsStatus] = useState("Tracking is off");
  const [currentCoords, setCurrentCoords] = useState<{lat:number,lng:number}|null>(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [notifications, setNotifications] = useState(true);

  useEffect(() => {
    const key = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;
    if (!key || key === "YOUR_GOOGLE_MAPS_API_KEY") return;
    if ((window as any).google?.maps) { setMapReady(true); return; }
    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=${key}&v=weekly`;
    script.async = true;
    script.onload = () => setMapReady(true);
    script.onerror = () => setGpsStatus("Google Maps failed to load. Check API key and billing.");
    document.head.appendChild(script);
  }, []);

  useEffect(() => {
    if (!mapReady || !(window as any).google?.maps) return;
    const el = document.getElementById("google-map");
    if (!el) return;
    const g = (window as any).google.maps;
    const map = new g.Map(el, {
      center: currentCoords || { lat: 27.75, lng: 77.1 }, zoom: 6,
      mapTypeControl: false, streetViewControl: false, fullscreenControl: true,
      styles: [{ featureType:"poi", stylers:[{visibility:"off"}] }]
    });
    listings.forEach((l, i) => {
      const marker = new g.Marker({ position:{lat:l.lat,lng:l.lng}, map, title:`${l.truck} • ${l.from} to ${l.to}` });
      const info = new g.InfoWindow({ content:`<div style="font-family:Arial;padding:4px"><b>${l.truck}</b><br>${l.from} → ${l.to}<br>${l.weight} kg capacity<br><b>₹${l.price.toLocaleString("en-IN")}</b></div>` });
      marker.addListener("click", () => info.open({anchor:marker,map}));
    });
    if (currentCoords) {
      new g.Marker({position:currentCoords,map,title:"This device location",icon:"https://maps.google.com/mapfiles/ms/icons/blue-dot.png"});
      map.setCenter(currentCoords); map.setZoom(10);
    }
  }, [mapReady, listings, currentCoords]);

  useEffect(() => {
    if (!trackingOn) return;
    if (!navigator.geolocation) { setGpsStatus("This browser does not support GPS location."); setTrackingOn(false); return; }
    setGpsStatus("Waiting for location permission…");
    const id = navigator.geolocation.watchPosition(
      p => {
        const coords = { lat:p.coords.latitude, lng:p.coords.longitude };
        setCurrentCoords(coords);
        setGpsStatus(`GPS active • accuracy ±${Math.round(p.coords.accuracy)} m`);
        // For a production build, send coordinates to a protected API/Supabase table with a booking-level access policy.
      },
      e => { setGpsStatus(e.code === 1 ? "Location permission denied." : "Unable to get GPS. Check device settings."); setTrackingOn(false); },
      { enableHighAccuracy:true, maximumAge:5000, timeout:15000 }
    );
    return () => navigator.geolocation.clearWatch(id);
  }, [trackingOn]);

  async function signIn() {
    if (!email.trim() || !password.trim()) { setToast("Enter email and password to continue."); return; }
    if (supabase) {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) { setToast(error.message); return; }
    } else {
      setToast("Demo mode: add Supabase keys to enable real authentication.");
    }
    setLoggedIn(true); setToast("");
  }
  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setLoggedIn(false); setActive("Overview");
  }
  function notify(message:string) { setToast(message); window.setTimeout(() => setToast(""), 3600); }
  function postShipment() {
    if (!from.trim() || !to.trim() || from.toLowerCase() === to.toLowerCase()) { notify("Enter different pickup and destination cities."); return; }
    notify(`Shipment request created: ${from} → ${to}. Demo request only until backend is connected.`);
    setActive("Find Transport");
  }
  function addCapacity() {
    const item: Listing = { id:"ER-"+Math.floor(3000+Math.random()*6000), truck:"New vehicle listing", driver:"Your profile", from, to, km:230, weight:Number(weight)||500, volume:Number(volume)||3, price:Number(budget)||3500, eta:"To be confirmed", status:"Available", rating:5, plate:"Pending verification", lat:27.1767, lng:78.0081, verified:false };
    setListings(prev => [item,...prev]); notify("Capacity added to this demo session. It is not yet published to a shared database.");
    setActive("My Capacity");
  }
  function sendMessage() {
    if (!chatText.trim()) return;
    setChatMessages(prev => [...prev,{sender:"You",text:chatText.trim(),time:new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}]);
    setChatText("");
  }

  const filteredListings = useMemo(() => listings.filter(l =>
    `${l.truck} ${l.driver} ${l.from} ${l.to} ${l.plate}`.toLowerCase().includes(query.toLowerCase()) &&
    (active !== "Find Transport" || (l.weight >= (Number(weight)||0) && l.price <= (Number(budget)||Infinity)))
  ), [listings, query, active, weight, budget]);

  if (!loggedIn) return (
    <main className="login-shell">
      <section className="login-visual">
        <div className="brand"><div className="brand-mark"><Route size={22}/></div><span>Empty<span className="brand-accent">Return</span></span></div>
        <div className="visual-copy">
          <div className="eyebrow"><span className="pulse-dot"/> SMARTER FREIGHT. FEWER EMPTY MILES.</div>
          <h1>Make every<br/><em>return trip</em><br/>count.</h1>
          <p>A smarter way to connect spare truck capacity with businesses that need reliable, affordable transport.</p>
          <div className="visual-stats">
            <div><strong>01</strong><span>List spare capacity</span></div>
            <div><strong>02</strong><span>Match a shipment</span></div>
            <div><strong>03</strong><span>Move goods smarter</span></div>
          </div>
        </div>
        <div className="visual-footer"><span>BUILT FOR INDIA'S BUSINESS NETWORK</span><span>AGRA · INDIA</span></div>
      </section>
      <section className="login-panel">
        <div className="login-top"><span className="secure-label"><ShieldCheck size={15}/> Secure workspace</span><span className="demo-label">MVP PREVIEW</span></div>
        <div className="login-form-wrap">
          <div className="mobile-brand brand"><div className="brand-mark"><Route size={20}/></div><span>Empty<span className="brand-accent">Return</span></span></div>
          <p className="overline">WELCOME TO EMPTYRETURN</p>
          <h2>Good logistics<br/>starts here.</h2>
          <p className="muted">Sign in to your workspace or explore the prototype.</p>
          <label className="field-label">I AM SIGNING IN AS</label>
          <div className="role-select">
            {(["shipper","carrier","admin"] as Role[]).map(r=><button key={r} className={role===r?"role-option selected":"role-option"} onClick={()=>setRole(r)}>
              {r==="shipper"?<Package size={18}/>:r==="carrier"?<Truck size={18}/>:<ShieldCheck size={18}/>}
              <span>{r==="shipper"?"SME / Shipper":r==="carrier"?"Truck Owner":"Admin"}</span>
            </button>)}
          </div>
          <form onSubmit={e=>{e.preventDefault();signIn()}}>
            <label className="field-label" htmlFor="email">EMAIL ADDRESS</label>
            <input id="email" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@company.com" autoComplete="email"/>
            <label className="field-label" htmlFor="password">PASSWORD</label>
            <div className="password-wrap"><input id="password" type={showPassword?"text":"password"} value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter your password" autoComplete="current-password"/><button type="button" className="icon-button" onClick={()=>setShowPassword(!showPassword)} aria-label="Toggle password visibility">{showPassword?<EyeOff size={18}/>:<Eye size={18}/>}</button></div>
            <div className="form-meta"><label className="remember"><input type="checkbox"/> Remember me</label><button type="button" className="text-button" onClick={()=>notify("Password reset needs Supabase email configuration.")}>Forgot password?</button></div>
            <button className="primary-button full" type="submit">Sign in to workspace <ArrowUpRight size={17}/></button>
          </form>
          <button className="demo-button" onClick={()=>{setEmail("demo@emptyreturn.in");setPassword("demo-preview");setLoggedIn(true);}}>Explore demo dashboard <ArrowUpRight size={16}/></button>
          <div className="login-disclaimer"><ShieldCheck size={15}/><span>Prototype mode: sample listings and numbers are illustrative, not live freight offers.</span></div>
        </div>
        <div className="login-bottom"><span>© 2026 EmptyReturn Logistics Exchange</span><button onClick={()=>notify("Contact: configure your official support email before launch.")}><CircleHelp size={15}/> Help</button></div>
      </section>
      {toast&&<div className="toast"><AlertTriangle size={17}/>{toast}<button onClick={()=>setToast("")}><X size={15}/></button></div>}
    </main>
  );

  const navItems = role==="shipper"
    ? [{label:"WORKSPACE",items:[["Overview",LayoutDashboard],["Find Transport",Search],["My Shipments",Package],["Messages",MessageCircle]]},{label:"ACCOUNT",items:[["My Profile",Users],["Notifications",Bell]]}]
    : role==="carrier"
    ? [{label:"WORKSPACE",items:[["Overview",LayoutDashboard],["My Capacity",Truck],["Bookings",ClipboardCheck],["Live Tracking",Navigation],["Messages",MessageCircle]]},{label:"ACCOUNT",items:[["My Profile",Users],["Verification",FileCheck2],["Notifications",Bell]]}]
    : [{label:"CONTROL CENTRE",items:[["Overview",LayoutDashboard],["Users & Verification",ShieldCheck],["All Bookings",ClipboardCheck],["Live Tracking",Navigation],["Reports",Activity]]},{label:"MANAGEMENT",items:[["Messages",MessageCircle],["Settings",Settings]]}];

  return (
    <main className="app-shell">
      <aside className={`sidebar ${mobileMenu?"sidebar-open":""}`}>
        <div className="brand sidebar-brand"><div className="brand-mark"><Route size={21}/></div><span>Empty<span className="brand-accent">Return</span></span><button className="mobile-close" onClick={()=>setMobileMenu(false)}><X size={18}/></button></div>
        <div className="workspace-pill"><div className="workspace-icon">{role==="shipper"?<Package size={17}/>:role==="carrier"?<Truck size={17}/>:<ShieldCheck size={17}/>}</div><div><strong>{roleNames[role]}</strong><span>{role==="admin"?"Control centre":"Business workspace"}</span></div><ChevronDown size={15}/></div>
        <div className="nav-scroll">{navItems.map(group=><div className="nav-group" key={group.label}><div className="nav-label">{group.label}</div>{group.items.map(([label,Icon]:any)=><button key={label} onClick={()=>{setActive(label);setMobileMenu(false);}} className={`nav-link ${active===label?"active":""}`}><Icon size={18}/><span>{label}</span>{label==="Messages"&&<span className="nav-count">2</span>}</button>)}</div>)}</div>
        <div className="sidebar-bottom"><div className="support-card"><div className="support-icon"><CircleHelp size={17}/></div><strong>Need a hand?</strong><p>Our logistics support team is here to help.</p><button onClick={()=>notify("Support centre needs a configured support contact.")}>Visit help centre <ArrowUpRight size={14}/></button></div><button className="nav-link logout" onClick={signOut}><LogOut size={18}/><span>Sign out</span></button><div className="user-mini"><div className="avatar">{role==="carrier"?"AS":role==="admin"?"AD":"SM"}</div><div><strong>{email.split("@")[0]||"Demo user"}</strong><span>{roleNames[role]}</span></div><button onClick={()=>setActive("My Profile")}><Settings size={17}/></button></div></div>
      </aside>
      {mobileMenu&&<button className="mobile-scrim" onClick={()=>setMobileMenu(false)} aria-label="Close navigation"/>}
      <section className="main-area">
        <header className="topbar"><button className="mobile-menu-button" onClick={()=>setMobileMenu(true)}><Menu size={21}/></button><div className="breadcrumb">Workspace <span>/</span> <strong>{active}</strong></div><div className="top-actions"><div className="system-status"><span className="status-dot"/> Prototype workspace</div><button className="top-icon" onClick={()=>{setActive("Notifications");setNotifications(false)}} aria-label="Notifications"><Bell size={19}/>{notifications&&<i/>}</button><div className="top-avatar">{role==="carrier"?"AS":role==="admin"?"AD":"SM"}</div></div></header>
        <div className="content">
          <div className="page-heading"><div><div className="overline">{role==="admin"?"PLATFORM CONTROL":role==="carrier"?"CARRIER PORTAL":"SHIPPER PORTAL"} <span className="heading-dot">•</span> {new Date().toLocaleDateString("en-IN",{weekday:"short",day:"2-digit",month:"short",year:"numeric"})}</div><h1>{active==="Overview"?"Good morning, "+(role==="carrier"?"Aman":role==="admin"?"Admin":"there")+".":active}</h1><p>{active==="Overview"?"Here's what's happening across your logistics workspace today.":pageDescription(active,role)}</p></div><div className="heading-actions">{role==="shipper"&&<button className="secondary-button" onClick={()=>setActive("My Shipments")}><Package size={16}/> My shipments</button>}{role==="carrier"&&<button className="primary-button" onClick={()=>setActive("My Capacity")}><Plus size={17}/> Add capacity</button>}{role==="admin"&&<button className="secondary-button" onClick={()=>notify("Report export is available after connecting the backend.")}>Export report <ArrowDownRight size={16}/></button>}</div></div>

          {active==="Overview"&&<Overview role={role} listings={listings} setActive={setActive} notify={notify}/>}
          {active==="Find Transport"&&<section className="panel"><div className="panel-heading"><div><h3>Find return-trip capacity</h3><p>Search illustrative listings by route, cargo size and budget.</p></div><span className="demo-chip">DEMO DATA</span></div><div className="search-form"><div className="input-group"><label>FROM</label><input value={from} onChange={e=>setFrom(e.target.value)} placeholder="Pickup city"/></div><div className="swap-route"><Route size={18}/></div><div className="input-group"><label>TO</label><input value={to} onChange={e=>setTo(e.target.value)} placeholder="Destination city"/></div><div className="input-group"><label>WEIGHT (KG)</label><input type="number" value={weight} onChange={e=>setWeight(e.target.value)}/></div><div className="input-group"><label>MAX BUDGET (₹)</label><input type="number" value={budget} onChange={e=>setBudget(e.target.value)}/></div><button className="primary-button" onClick={()=>notify("Filters applied to sample listings.")}><Search size={17}/> Search</button></div><div className="results-heading"><strong>{filteredListings.length} potential matches</strong><span>Only eligible sample listings are shown</span></div><ListingTable listings={filteredListings} onBook={setBooking}/></section>}
          {active==="My Shipments"&&<section className="two-col"><div className="panel"><div className="panel-heading"><div><h3>Post a shipment</h3><p>Tell carriers what needs to move.</p></div><span className="step-number">01</span></div><div className="form-grid"><div className="input-group"><label>PICKUP CITY</label><input value={from} onChange={e=>setFrom(e.target.value)}/></div><div className="input-group"><label>DESTINATION CITY</label><input value={to} onChange={e=>setTo(e.target.value)}/></div><div className="input-group"><label>CARGO WEIGHT (KG)</label><input type="number" value={weight} onChange={e=>setWeight(e.target.value)}/></div><div className="input-group"><label>VOLUME (M³)</label><input type="number" value={volume} onChange={e=>setVolume(e.target.value)}/></div><div className="input-group"><label>MAXIMUM BUDGET (₹)</label><input type="number" value={budget} onChange={e=>setBudget(e.target.value)}/></div><div className="input-group"><label>GOODS TYPE</label><select><option>General goods</option><option>Fragile</option><option>Perishable</option><option>Industrial material</option></select></div><div className="input-group full-width"><label>HANDLING NOTES</label><textarea placeholder="Loading needs, delivery deadline, special instructions…"/></div></div><button className="primary-button" onClick={postShipment}>Find matching trucks <ArrowUpRight size={16}/></button><p className="form-note"><ShieldCheck size={14}/> Your contact details should remain private until a booking is accepted.</p></div><div className="panel soft-panel"><div className="panel-heading"><div><h3>Shipment checklist</h3><p>Help carriers quote accurately.</p></div><ClipboardCheck size={20}/></div>{["Accurate weight and dimensions","Clear pickup and drop-off address","Loading and delivery time window","Cargo handling requirements","Budget or target rate"].map((x,i)=><div className="check-row" key={x}><CheckCircle2 size={18}/><span>{x}</span><span className="check-num">0{i+1}</span></div>)}<div className="notice"><AlertTriangle size={17}/><span>Do not enter Aadhaar numbers or other sensitive identity data in shipment notes.</span></div></div></section>}
          {active==="My Capacity"&&<section className="two-col"><div className="panel"><div className="panel-heading"><div><h3>List spare return capacity</h3><p>Tell shippers about your planned return trip.</p></div><span className="step-number">01</span></div><div className="form-grid"><div className="input-group"><label>CURRENT / PICKUP CITY</label><input value={from} onChange={e=>setFrom(e.target.value)}/></div><div className="input-group"><label>RETURN DESTINATION</label><input value={to} onChange={e=>setTo(e.target.value)}/></div><div className="input-group"><label>AVAILABLE WEIGHT (KG)</label><input type="number" value={weight} onChange={e=>setWeight(e.target.value)}/></div><div className="input-group"><label>AVAILABLE VOLUME (M³)</label><input type="number" value={volume} onChange={e=>setVolume(e.target.value)}/></div><div className="input-group"><label>ASKING PRICE (₹)</label><input type="number" value={budget} onChange={e=>setBudget(e.target.value)}/></div><div className="input-group"><label>VEHICLE TYPE</label><select><option>Light commercial vehicle</option><option>Medium truck</option><option>Heavy truck</option><option>Container truck</option></select></div><div className="input-group full-width"><label>TRUCK REGISTRATION NUMBER</label><input placeholder="e.g. UP80 AB 1234"/></div></div><button className="primary-button" onClick={addCapacity}><Plus size={17}/> Publish capacity (demo)</button><p className="form-note"><ShieldCheck size={14}/> Vehicle and driver verification must be completed before real bookings.</p></div><div className="panel soft-panel"><div className="panel-heading"><div><h3>Verification status</h3><p>Required before live marketplace launch.</p></div><ShieldCheck size={20}/></div>{[{name:"Mobile number",state:"Not connected"},{name:"Driver identity",state:"Pending review"},{name:"Vehicle registration",state:"Pending review"},{name:"Permit & insurance",state:"Pending review"}].map((x)=><div className="verification-row" key={x.name}><div className="verification-icon"><FileCheck2 size={17}/></div><div><strong>{x.name}</strong><span>{x.state}</span></div><span className="pending-chip">PENDING</span></div>)}<div className="notice"><ShieldCheck size={17}/><span>For privacy, collect identity documents only through a secure, access-controlled verification flow.</span></div></div></section>}
          {active==="Live Tracking"&&<section className="panel"><div className="panel-heading"><div><h3>Live fleet map</h3><p>Map markers below are sample listings. GPS from this device is shown only after permission is granted.</p></div><button className={trackingOn?"secondary-button":"primary-button"} onClick={()=>setTrackingOn(!trackingOn)}>{trackingOn?<><X size={16}/> Stop my GPS</>:<><LocateFixed size={16}/> Share this device location</>}</button></div><div className="tracking-status"><span className={trackingOn?"status-dot":"status-dot grey"}/><strong>{gpsStatus}</strong><span className="muted">Device GPS is not automatically the truck's GPS.</span></div><MapPanel mapReady={mapReady}/><div className="tracking-foot"><div><Navigation size={17}/><span><strong>Live driver tracking</strong><small>Requires driver app/browser permission and secure location updates.</small></span></div><div><ShieldCheck size={17}/><span><strong>Booking-level access</strong><small>Only authorised participants should view a trip's live location.</small></span></div></div></section>}
          {active==="Messages"&&<section className="panel chat-panel"><div className="panel-heading"><div><h3>Private booking chat</h3><p>Keep shipment coordination in the platform.</p></div><span className="secure-label"><ShieldCheck size={15}/> Private demo chat</span></div><div className="chat-contact"><div className="avatar">AS</div><div><strong>Aman Singh</strong><span><i className="status-dot"/> Verified carrier (sample)</span></div><button className="top-icon"><CircleHelp size={18}/></button></div><div className="chat-messages">{chatMessages.map((m,i)=><div className={`message-row ${m.sender==="You"?"mine":""}`} key={i}><div className="message-bubble"><span className="message-sender">{m.sender}</span><p>{m.text}</p><small>{m.time}</small></div></div>)}</div><div className="chat-compose"><input value={chatText} onChange={e=>setChatText(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendMessage()} placeholder="Write a message…"/><button className="primary-button" onClick={sendMessage}><Send size={16}/> Send</button></div><p className="form-note">Demo chat only. Real-time private messaging needs database persistence, access policies and abuse reporting.</p></section>}
          {active==="Users & Verification"&&<section className="panel"><div className="panel-heading"><div><h3>User verification queue</h3><p>Example review queue for the admin experience.</p></div><span className="pending-chip">3 NEED REVIEW</span></div><div className="table-wrap"><table><thead><tr><th>USER</th><th>TYPE</th><th>DOCUMENTS</th><th>STATUS</th><th>ACTION</th></tr></thead><tbody>{[["Aman Singh","Carrier","Driving licence · RC","Pending"],["Ravi Kumar","Carrier","RC · Insurance","Pending"],["Shree Traders","SME","Business details","Review"]].map((r,i)=><tr key={r[0]}><td><strong>{r[0]}</strong><small>ER-U10{i+1}</small></td><td>{r[1]}</td><td>{r[2]}</td><td><span className="pending-chip">{r[3]}</span></td><td><button className="table-action" onClick={()=>notify("Document review requires secure backend storage and an audit trail.")}>Review <ArrowUpRight size={14}/></button></td></tr>)}</tbody></table></div><div className="notice"><AlertTriangle size={17}/><span>Do not use real Aadhaar images in this demo. Implement lawful identity verification, restricted access, retention limits and audit logs before production.</span></div></section>}
          {(active==="Bookings"||active==="All Bookings")&&<section className="panel"><div className="panel-heading"><div><h3>Booking management</h3><p>Track booking lifecycle and handover milestones.</p></div></div><ListingTable listings={listings} onBook={setBooking}/></section>}
          {active==="Notifications"&&<section className="panel"><div className="panel-heading"><div><h3>Notifications</h3><p>Updates related to bookings, messages and verification.</p></div><button className="secondary-button" onClick={()=>notify("Demo notifications marked as read.")}>Mark all read</button></div>{[{title:"New return capacity available",desc:"A sample carrier listed Agra → Delhi capacity.",time:"10 min ago",icon:Truck},{title:"Verification reminder",desc:"Complete profile checks before accepting bookings.",time:"1 hour ago",icon:ShieldCheck},{title:"Booking update",desc:"A sample booking is awaiting confirmation.",time:"Yesterday",icon:Package}].map((n,i)=><div className="notification-row" key={n.title}><div className="notification-icon"><n.icon size={18}/></div><div><strong>{n.title}</strong><p>{n.desc}</p><small>{n.time}</small></div></div>)}</section>}
          {active==="My Profile"&&<section className="panel"><div className="panel-heading"><div><h3>Profile & account</h3><p>Manage your workspace details.</p></div></div><div className="profile-card"><div className="profile-large">{role==="carrier"?"AS":role==="admin"?"AD":"SM"}</div><div><h3>{email.split("@")[0]||"Demo user"}</h3><p>{roleNames[role]} · Demo profile</p><span className="pending-chip">NOT VERIFIED</span></div></div><div className="form-grid profile-fields"><div className="input-group"><label>EMAIL</label><input value={email} readOnly/></div><div className="input-group"><label>ACCOUNT ROLE</label><input value={roleNames[role]} readOnly/></div><div className="input-group"><label>PHONE NUMBER</label><input placeholder="Add after backend setup"/></div><div className="input-group"><label>BUSINESS / FLEET NAME</label><input placeholder="Enter business name"/></div></div><div className="notice"><ShieldCheck size={17}/><span>Production profiles must be stored in the database with row-level security; never store passwords directly in a user profile.</span></div></section>}
          {active==="Reports"&&<Overview role={role} listings={listings} setActive={setActive} notify={notify}/>}
          {active==="Settings"&&<section className="panel"><div className="panel-heading"><div><h3>Platform settings</h3><p>Prototype preferences and integration status.</p></div></div>{[{name:"Supabase database",value:supabase?"Configured":"Not configured"},{name:"Google Maps",value:mapReady?"Loaded":"API key required"},{name:"GPS publishing endpoint",value:"Not implemented"},{name:"Payment gateway",value:"Not connected"}].map(x=><div className="settings-row" key={x.name}><div><strong>{x.name}</strong><p>{x.value}</p></div><span className={x.value==="Configured"||x.value==="Loaded"?"success-chip":"pending-chip"}>{x.value==="Configured"||x.value==="Loaded"?"READY":"SETUP"}</span></div>)}</section>}
          {active!=="Overview"&&!["Find Transport","My Shipments","My Capacity","Live Tracking","Messages","Users & Verification","Bookings","All Bookings","Notifications","My Profile","Reports","Settings"].includes(active)&&<section className="panel"><h3>{active}</h3><p className="muted">This module is part of the UI starter. Connect its backend workflow before production use.</p></section>}
          <footer className="app-footer"><span>© 2026 EmptyReturn Logistics Exchange</span><span><span className="status-dot grey"/> Prototype · Sample data only</span></footer>
        </div>
      </section>
      {booking&&<div className="modal-scrim" onClick={()=>setBooking(null)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setBooking(null)}><X size={18}/></button><div className="modal-icon"><Truck size={22}/></div><p className="overline">POTENTIAL MATCH</p><h2>{booking.from} → {booking.to}</h2><p className="muted">{booking.truck} · {booking.plate}</p><div className="modal-details"><div><span>Available weight</span><strong>{booking.weight.toLocaleString()} kg</strong></div><div><span>Available volume</span><strong>{booking.volume} m³</strong></div><div><span>Indicative price</span><strong>{money(booking.price)}</strong></div><div><span>Carrier rating</span><strong>★ {booking.rating}</strong></div></div><div className="notice"><AlertTriangle size={17}/><span>Sample offer only. No real booking or payment will be made.</span></div><button className="primary-button full" onClick={()=>{setBooking(null);setActive("Messages");notify("Demo booking request noted. No carrier has been contacted.");}}>Request booking <ArrowUpRight size={16}/></button></div></div>}
      {toast&&<div className="toast"><CheckCircle2 size={17}/>{toast}<button onClick={()=>setToast("")}><X size={15}/></button></div>}
    </main>
  );
}

function pageDescription(active:string,role:Role) {
  const descriptions:Record<string,string> = {
    "Find Transport":"Compare potential return-trip options that fit your shipment.",
    "My Shipments":"Create and manage your business shipment requests.",
    "My Capacity":"Publish spare capacity on a planned return journey.",
    "Live Tracking":"Monitor trip location and journey status.",
    "Messages":"Coordinate shipment details in one place.",
    "Users & Verification":"Review user onboarding and document verification.",
    "Bookings":"Review trip requests and booking milestones.",
    "All Bookings":"Monitor marketplace booking activity.",
    "Notifications":"Stay informed about important activity.",
    "My Profile":"Manage your account and verification details.",
    "Reports":"Review marketplace activity and pilot metrics.",
    "Settings":"Manage integrations and platform preferences."
  };
  return descriptions[active]||"Manage your EmptyReturn workspace.";
}

function Overview({role,listings,setActive,notify}:any) {
  const stats = role==="carrier"
    ? [{label:"Active capacity",value:"04",delta:"+1 this week",icon:Truck,tone:"blue"},{label:"Bookings received",value:"12",delta:"3 need attention",icon:Package,tone:"green"},{label:"Potential earnings",value:"₹24,800",delta:"Illustrative only",icon:Wallet,tone:"orange"},{label:"Profile rating",value:"4.9",delta:"Sample rating",icon:Gauge,tone:"purple"}]
    : role==="admin"
    ? [{label:"Registered users",value:"248",delta:"Sample metric",icon:Users,tone:"blue"},{label:"Pending verification",value:"18",delta:"Review queue",icon:ShieldCheck,tone:"orange"},{label:"Active bookings",value:"36",delta:"Sample metric",icon:Package,tone:"green"},{label:"Platform commission",value:"₹42,600",delta:"Illustrative only",icon:CircleDollarSign,tone:"purple"}]
    : [{label:"Shipments posted",value:"08",delta:"+2 this week",icon:Package,tone:"blue"},{label:"Potential matches",value:"14",delta:"Across sample routes",icon:Route,tone:"green"},{label:"Bookings in progress",value:"03",delta:"1 update available",icon:Truck,tone:"orange"},{label:"Indicative savings",value:"₹8,450",delta:"Demo calculation only",icon:Wallet,tone:"purple"}];
  return <>
    <div className="metrics-grid">{stats.map((s:any)=><div className="metric-card" key={s.label}><div className={`metric-icon ${s.tone}`}><s.icon size={19}/></div><div className="metric-label">{s.label}</div><div className="metric-value">{s.value}</div><div className="metric-delta"><span>{s.delta}</span></div><div className="metric-corner"><ArrowUpRight size={17}/></div></div>)}</div>
    <div className="dashboard-grid"><div className="panel route-panel"><div className="panel-heading"><div><h3>Return capacity near your routes</h3><p>Potential matches based on sample listings.</p></div><button className="text-button" onClick={()=>setActive(role==="carrier"?"My Capacity":"Find Transport")}>View all <ArrowUpRight size={15}/></button></div><div className="route-list">{listings.slice(0,3).map((l:Listing)=><div className="route-item" key={l.id}><div className="route-visual"><div className="route-pin"><MapPin size={17}/></div><div className="route-line"/><div className="route-pin end"><MapPin size={17}/></div></div><div className="route-main"><strong>{l.from} <span>→</span> {l.to}</strong><p>{l.truck} · {l.weight.toLocaleString()} kg available</p><div className="route-meta"><span><Clock3 size={13}/>{l.eta}</span><span><ShieldCheck size={13}/>{l.verified?"Verified sample":"Verification pending"}</span></div></div><div className="route-price"><strong>{money(l.price)}</strong><span>indicative</span><button onClick={()=>setActive(role==="carrier"?"My Capacity":"Find Transport")}>Details <ArrowUpRight size={13}/></button></div></div>)}</div></div>
      <div className="panel activity-panel"><div className="panel-heading"><div><h3>Journey activity</h3><p>Example operational timeline</p></div><Activity size={19}/></div><div className="timeline">{[{title:"Capacity listed",desc:"Agra → Delhi return route",time:"09:15 AM",done:true},{title:"Shipment matched",desc:"380 kg general goods",time:"10:20 AM",done:true},{title:"Booking confirmation",desc:"Awaiting both parties",time:"Pending",done:false},{title:"Pickup & live tracking",desc:"GPS starts after driver opts in",time:"Upcoming",done:false}].map((x,i)=><div className="timeline-row" key={x.title}><div className={`timeline-dot ${x.done?"done":""}`}>{x.done?<CheckCircle2 size={15}/>:<span/>}</div><div><strong>{x.title}</strong><p>{x.desc}</p><small>{x.time}</small></div></div>)}</div><button className="secondary-button full" onClick={()=>setActive("Live Tracking")}><Navigation size={16}/> Open tracking workspace</button></div></div>
    <div className="panel lower-panel"><div className="panel-heading"><div><h3>Marketplace listings</h3><p>Illustrative sample data to demonstrate the workflow.</p></div><button className="secondary-button" onClick={()=>setActive(role==="carrier"?"My Capacity":"Find Transport")}>{role==="carrier"?"Manage capacity":"Find transport"} <ArrowUpRight size={15}/></button></div><ListingTable listings={listings.slice(0,3)} onBook={(l:Listing)=>notify("Open Find Transport to request this sample booking.")}/></div>
    <div className="demo-warning"><ShieldCheck size={17}/><div><strong>Prototype workspace</strong><span>Numbers, ratings, users, routes and bookings are sample data. Connect the database, verification flow and GPS publishing service before using this with real customers.</span></div></div>
  </>;
}

function ListingTable({listings,onBook}:any) {
  return <div className="table-wrap"><table><thead><tr><th>VEHICLE / CARRIER</th><th>ROUTE</th><th>FREE CAPACITY</th><th>INDICATIVE PRICE</th><th>STATUS</th><th></th></tr></thead><tbody>{listings.map((l:Listing)=><tr key={l.id}><td><div className="vehicle-cell"><div className="vehicle-icon"><Truck size={18}/></div><div><strong>{l.truck}</strong><small>{l.driver} · {l.plate}</small></div></div></td><td><strong>{l.from} → {l.to}</strong><small>{l.km} km estimated</small></td><td><strong>{l.weight.toLocaleString()} kg</strong><small>{l.volume} m³ volume</small></td><td><strong>{money(l.price)}</strong><small>Indicative only</small></td><td><span className={l.verified?"success-chip":"pending-chip"}>{l.verified?"Verified sample":"Pending"}</span></td><td><button className="table-action" onClick={()=>onBook(l)}>Details <ArrowUpRight size={14}/></button></td></tr>)}</tbody></table>{listings.length===0&&<div className="empty-state"><Search size={24}/><strong>No sample matches found</strong><span>Try adjusting your route, weight or budget.</span></div>}</div>;
}

function MapPanel({mapReady}: {mapReady:boolean}) {
  return <div className="map-wrap"><div id="google-map" className="google-map"/>{!mapReady&&<div className="map-placeholder"><div className="map-grid"/><div className="map-route route-a"/><div className="map-route route-b"/><div className="map-marker marker-a"><Truck size={17}/></div><div className="map-marker marker-b"><Truck size={17}/></div><div className="map-marker marker-c"><Truck size={17}/></div><div className="map-caption"><div className="map-caption-icon"><MapPin size={19}/></div><div><strong>India freight network</strong><span>{process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY?"Loading Google Maps…":"Add Google Maps API key to enable interactive map"}</span></div></div></div>}<div className="map-legend"><span><i className="legend-dot blue-dot"/>Sample truck listings</span><span><i className="legend-dot green-dot"/>Device location (if enabled)</span></div></div>;
}
