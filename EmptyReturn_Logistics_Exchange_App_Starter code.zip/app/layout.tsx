import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "EmptyReturn | Logistics Exchange",
  description: "Turn unused return-trip truck capacity into delivery opportunities.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
