# EmptyReturn Logistics Exchange — MVP starter

A polished Next.js web-app starter for the EmptyReturn B2B freight marketplace concept:
SMEs post shipment needs, carriers list spare return-trip capacity, and the platform helps the two sides connect.

## Important: what works in this starter

- Responsive app shell and login screen with Shipper / Truck Owner / Admin role selector.
- Demo dashboards, sample capacity listings, shipment and capacity forms, match search, booking preview, demo chat, notifications and admin verification queue.
- Google Maps integration slot. If configured, sample listings appear as markers.
- Browser geolocation opt-in for the device currently using the page.
- Supabase client sign-in wiring and a starter SQL schema.

## What is NOT production-ready yet

This is an MVP starter, not a deployed logistics business. Demo data stays in browser memory and disappears on refresh. The demo login bypasses real auth only when you click **Explore demo dashboard**. A real account login requires Supabase credentials and a user created in Supabase Auth. The chat, booking request, document verification, shipment publishing, GPS broadcasting to other users, payment and notifications are not connected to shared backend workflows yet.

**A Google Map is not live truck tracking by itself.** Actual truck tracking needs a driver device with permission, periodic secure location uploads, authenticated booking participants, realtime updates, trip start/stop controls, retention limits and background-location behavior. Browser geolocation works only while the page is open and permission is granted; it is not a replacement for a native driver app.

## 1. Run locally

Install Node.js 20 LTS or newer, then from this folder:

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000. Without keys, use **Explore demo dashboard** to inspect the interface.

## 2. Create Supabase backend

1. Create a project at https://supabase.com.
2. In Project Settings → API, copy Project URL and anon/public key into `.env.local`.
3. In Supabase SQL Editor, review and run `supabase/schema.sql`.
4. In Authentication → Users, create a test user with email/password.
5. Sign in with that user from the app. For production, add a real signup/onboarding flow and server-side role assignment.

Never expose `SUPABASE_SERVICE_ROLE_KEY` in client code or a `NEXT_PUBLIC_` variable. The included RLS policies are a starting point and must be security-reviewed before real data is used. The starter does not yet read/write all forms against the database.

## 3. Enable Google Maps

1. Create/select a project at https://console.cloud.google.com/.
2. Enable **Maps JavaScript API** and attach billing. Add a key restriction for your production website domains.
3. Add the key to `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY` in `.env.local`.
4. Restart the dev server. The Live Tracking page will load Google Maps and show sample listing markers.

For production route matching, also decide whether to use Google Routes API or another routing provider. Restrict API keys and monitor usage/billing. Do not publish an unrestricted key.

## 4. Deploy to GitHub + Vercel

1. Create a new private GitHub repository.
2. Upload/commit this folder. Do not commit `.env.local`.
3. In https://vercel.com, choose **Add New → Project**, import the GitHub repository, and deploy.
4. In Vercel → Project → Settings → Environment Variables, add:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY`
5. Redeploy after adding environment variables.
6. Add your Vercel production domain to Google Maps key restrictions and any Supabase Auth redirect URL allowlists.

## 5. Real live GPS architecture

Recommended first production flow:

1. Carrier accepts a booking and taps **Start trip**.
2. The carrier device explicitly grants location permission.
3. A protected API endpoint validates the logged-in carrier and active booking.
4. The endpoint stores location/accuracy/time in `trip_locations`, with a rate limit.
5. Supabase Realtime or a short polling interval updates the shipper map only for the two booking participants and authorized admin roles.
6. Carrier taps **End trip**; tracking stops and the UI explains that it has stopped.
7. Store only the location history needed for support/safety and define a retention policy.

Do not stream location before a confirmed trip or expose every driver's location publicly. A browser tab may stop reporting in the background on mobile. For reliable background GPS, consider a native driver app or a carefully evaluated mobile framework.

## 6. Identity and safety

- Do not ask users to upload Aadhaar images or store Aadhaar numbers casually. Minimize identity data and use a legally appropriate verification provider/workflow after professional review.
- Keep RC, insurance and permit documents in a private storage bucket; use short-lived signed URLs and strict access policies.
- Add consent, privacy policy, terms, cargo exclusions, insurance/liability terms, dispute handling and account deletion.
- Add server-side admin authorization, audit logs, rate limiting, abuse reporting and tested row-level security.
- Add a payment provider only after legal, tax and refund flows are reviewed.

## 7. Suggested build sequence

1. Real authentication, onboarding and roles.
2. Database-connected shipment/capacity forms.
3. Matching engine with hard eligibility rules (weight, volume, vehicle type, route, timing).
4. Booking lifecycle and private chat.
5. Verification queue and secure private document storage.
6. Booking-scoped live GPS and Google Maps.
7. Notifications, payment integration, monitoring and security review.
8. Small pilot on selected routes before public launch.

## Tech stack

- Next.js + React + TypeScript
- Supabase Auth + PostgreSQL + Row Level Security
- Google Maps JavaScript API
- Vercel hosting + GitHub source control

The dashboard metrics, truck locations, carrier names, ratings and prices shown in demo mode are illustrative only.
